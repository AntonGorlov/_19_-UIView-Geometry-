//
//  ViewController.m
//  UIView Geometry (Lesson 19)
//
//  Created by Anton Gorlov on 14.12.15.
//  Copyright © 2015 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak,nonatomic) UIView* testView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView* view =[[UIView alloc] initWithFrame:CGRectMake(100, 150, 200, 50)];
    view.backgroundColor=[[UIColor lightGrayColor] colorWithAlphaComponent:0.8];
    [self.view addSubview:view];
    
    
    UIView* view2=[[UIView alloc]initWithFrame:CGRectMake(80, 130, 50, 250)];
    view2.backgroundColor=[[UIColor brownColor] colorWithAlphaComponent:0.8];
    [self.view addSubview:view2];
    
    self.testView = view2;
    
    //ставим view на передний план
    [self.view bringSubviewToFront:view];
    
    view2.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight|UIViewAutoresizingFlexibleRightMargin;
    view.autoresizingMask=UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleBottomMargin;
    }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(UIInterfaceOrientationMask) supportedInterfaceOrientations {//какие ориентации работают
    
    return  UIInterfaceOrientationMaskAll;
}

-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSLog(@"viewWillAppear");
}
//1-й вариант
- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id<UIViewControllerTransitionCoordinator>)coordinator
{
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    //NSLog(@"\n frame= %@ \n bounds=%@ \n",NSStringFromCGRect(self.testView.frame),NSStringFromCGRect(self.testView.bounds));

    NSLog(@"\n frame= %@ \n bounds=%@ \n",NSStringFromCGRect(self.view.frame),NSStringFromCGRect(self.view.bounds));

    
    CGPoint origin =CGPointZero;
    origin =[self.view convertPoint:origin toView:self.view.window];
    NSLog(@"origin = %@",NSStringFromCGPoint(origin));
    
   
    CGRect r =self.view.bounds;
    r.origin.y=0;
    r.origin.x= CGRectGetWidth(r)-100;
    r.size=CGSizeMake(100, 100);
    
    UIView* v =[[UIView alloc] initWithFrame:r];
    v.backgroundColor=[[UIColor blueColor] colorWithAlphaComponent:0.8];
    [self.view addSubview:v];
    
}

# pragma mark - Orientation

-(BOOL) shouldAutorotate { // on/off orientation
    return YES;
}



// 2 метода,которые перерисовуют views
-(void) viewWillLayoutSubviews {
    [super viewWillLayoutSubviews];
    NSLog(@"viewWillLayoutSubviews - перерисует!!!");
}

-(void) viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    NSLog(@"viewDidLayoutSubviews - перерисовал!!!");

}
@end
